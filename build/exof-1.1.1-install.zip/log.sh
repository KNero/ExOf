tail -50f ./logs/exof.log
